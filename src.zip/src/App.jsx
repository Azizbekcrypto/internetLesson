import { useState } from 'react'
import InternetLesson from './InternetLesson.jsx'
import PmLesson1 from './PmLesson1.jsx'

// DEV HOME — darslarni tanlab ko'rish uchun ichki sahifa (LMS'ga bormaydi).
// Tanlov sessionStorage'da saqlanadi: dars ichida sahifa yangilansa ham dars ochiq qoladi
// (jonli rejim reload-testlari uchun muhim). ⌂ tugma bosh sahifaga qaytaradi.
const LESSONS = [
  { key: 'internet', emoji: '🌐', title: 'Internet qanday ishlaydi', sub: 'HTML moduli · 1-dars — brauzer, domen, DNS, server · 20 ekran · jonli dars', comp: InternetLesson },
  { key: 'pm', emoji: '🎯', title: 'Kim mening foydalanuvchim?', sub: 'PM moduli · 1-dars — KIM + MUAMMO + YECHIM · 18 ekran', comp: PmLesson1 },
]

export default function App() {
  const [sel, setSel] = useState(() => { try { return sessionStorage.getItem('devLesson') } catch { return null } })
  const open = (k) => { try { sessionStorage.setItem('devLesson', k) } catch {} ; setSel(k) }
  const home = () => { try { sessionStorage.removeItem('devLesson') } catch {} ; setSel(null) }
  const lesson = LESSONS.find(l => l.key === sel)

  if (lesson) {
    const L = lesson.comp
    return (
      <>
        <L />
        <button onClick={home} title="Bosh sahifa — boshqa darsni tanlash" aria-label="Bosh sahifa" style={{ position: 'fixed', bottom: 14, left: 14, zIndex: 950, width: 40, height: 40, borderRadius: 12, border: 'none', background: '#FFFFFF', color: '#5A5A60', fontSize: 19, lineHeight: 1, cursor: 'pointer', boxShadow: '0 6px 18px -6px rgba(58,53,48,0.35)', opacity: 0.55, transition: 'opacity 0.2s' }}
          onMouseEnter={e => { e.currentTarget.style.opacity = 1 }} onMouseLeave={e => { e.currentTarget.style.opacity = 0.55 }}>⌂</button>
      </>
    )
  }

  return (
    <div style={{ minHeight: '100dvh', background: '#F6F4EF', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: 24, fontFamily: "'Manrope', system-ui, sans-serif" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Source+Serif+4:opsz,wght@8..60,600&family=Manrope:wght@500;600;700&display=swap');
        .home-card { display: flex; align-items: center; gap: 18px; width: 100%; max-width: 560px; text-align: left; background: #fff; border: none; border-radius: 18px; padding: 22px 24px; cursor: pointer; box-shadow: 0 8px 24px -10px rgba(58,53,48,0.18); transition: transform 0.2s, box-shadow 0.2s; }
        .home-card:hover { transform: translateY(-3px); box-shadow: 0 16px 34px -12px rgba(255,79,40,0.35); }
        .home-card:hover .home-arrow { color: #FF4F28; transform: translateX(4px); }
      `}</style>
      <p style={{ margin: '0 0 8px', fontSize: 12, fontWeight: 700, letterSpacing: '0.18em', textTransform: 'uppercase', color: '#FF4F28' }}>CoddyCamp · Darslar</p>
      <h1 style={{ margin: '0 0 28px', fontFamily: "'Source Serif 4', Georgia, serif", fontWeight: 600, fontSize: 'clamp(26px,4vw,38px)', color: '#0E0E10', textAlign: 'center' }}>Qaysi darsni ochamiz?</h1>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14, width: '100%', alignItems: 'center' }}>
        {LESSONS.map(l => (
          <button key={l.key} className="home-card" onClick={() => open(l.key)}>
            <span style={{ fontSize: 34, flexShrink: 0 }}>{l.emoji}</span>
            <span style={{ flex: 1, minWidth: 0 }}>
              <span style={{ display: 'block', fontFamily: "'Source Serif 4', Georgia, serif", fontWeight: 600, fontSize: 'clamp(17px,2.4vw,21px)', color: '#0E0E10' }}>{l.title}</span>
              <span style={{ display: 'block', marginTop: 3, fontSize: 13, fontWeight: 500, color: '#5A5A60' }}>{l.sub}</span>
            </span>
            <span className="home-arrow" style={{ fontSize: 20, color: '#A7A6A2', transition: 'transform 0.2s, color 0.2s', flexShrink: 0 }}>→</span>
          </button>
        ))}
      </div>
    </div>
  )
}
